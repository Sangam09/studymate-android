package com.studymate.local.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StudyDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "studymate_local.db";
    private static final int DB_VERSION = 2;
    private static volatile StudyDatabase instance;

    public static StudyDatabase getInstance(Context context) {
        if (instance == null) {
            synchronized (StudyDatabase.class) {
                if (instance == null) instance = new StudyDatabase(context.getApplicationContext());
            }
        }
        return instance;
    }

    private StudyDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE documents (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT NOT NULL," +
                "file_path TEXT NOT NULL," +
                "format TEXT NOT NULL," +
                "page_count INTEGER NOT NULL," +
                "word_count INTEGER NOT NULL," +
                "created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE document_pages (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "document_id INTEGER NOT NULL," +
                "page_number INTEGER NOT NULL," +
                "content TEXT NOT NULL," +
                "FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX idx_pages_document_page ON document_pages(document_id, page_number)");
        db.execSQL("CREATE TABLE study_notes (" +
                "document_id INTEGER PRIMARY KEY," +
                "notes TEXT NOT NULL," +
                "updated_at INTEGER NOT NULL," +
                "FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE chat_messages (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "document_id INTEGER NOT NULL," +
                "role TEXT NOT NULL," +
                "content TEXT NOT NULL," +
                "created_at INTEGER NOT NULL," +
                "FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE)");
        createStudyToolsTables(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) createStudyToolsTables(db);
    }

    private void createStudyToolsTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS flashcards (id INTEGER PRIMARY KEY AUTOINCREMENT, document_id INTEGER NOT NULL, front TEXT NOT NULL, back TEXT NOT NULL, due_at INTEGER NOT NULL, interval_days INTEGER NOT NULL DEFAULT 0, repetitions INTEGER NOT NULL DEFAULT 0, ease REAL NOT NULL DEFAULT 2.5, last_grade INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_cards_due ON flashcards(due_at)");
        db.execSQL("CREATE TABLE IF NOT EXISTS exam_sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, document_id INTEGER NOT NULL, title TEXT NOT NULL, total INTEGER NOT NULL, correct INTEGER NOT NULL, completed_at INTEGER NOT NULL, FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE IF NOT EXISTS topic_progress (id INTEGER PRIMARY KEY AUTOINCREMENT, document_id INTEGER NOT NULL, topic TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, correct INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL, UNIQUE(document_id,topic), FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE)");
    }

    public List<SearchHit> searchLibrary(String query, int limit) {
        List<SearchHit> hits = new ArrayList<>();
        String[] terms = query.trim().split("\\s+");
        StringBuilder where = new StringBuilder();
        List<String> args = new ArrayList<>();
        for (String term : terms) {
            if (term.length() < 3) continue;
            if (where.length() > 0) where.append(" OR ");
            where.append("p.content LIKE ?");
            args.add("%" + term.replace("%", "") + "%");
        }
        if (where.length() == 0) { where.append("p.content LIKE ?"); args.add("%" + query.trim() + "%"); }
        args.add(String.valueOf(limit));
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT d.title,p.page_number,substr(p.content,1,500) FROM document_pages p JOIN documents d ON d.id=p.document_id WHERE (" + where + ") ORDER BY d.title,p.page_number LIMIT ?",
                args.toArray(new String[0]))) {
            while (c.moveToNext()) hits.add(new SearchHit(c.getString(0), c.getInt(1), c.getString(2)));
        }
        return hits;
    }

    /** Adds a card only when the same front is not already present for this document. */
    public boolean addFlashcard(long documentId, String front, String back) {
        if (front == null || back == null || front.trim().isEmpty() || back.trim().isEmpty()) return false;
        SQLiteDatabase db = getWritableDatabase();
        try (Cursor c = db.rawQuery("SELECT 1 FROM flashcards WHERE document_id=? AND lower(front)=lower(?) LIMIT 1",
                new String[]{String.valueOf(documentId), front.trim()})) {
            if (c.moveToFirst()) return false;
        }
        ContentValues v = new ContentValues();
        v.put("document_id", documentId);
        v.put("front", front.trim());
        v.put("back", back.trim());
        v.put("due_at", System.currentTimeMillis());
        return db.insert("flashcards", null, v) != -1;
    }

    public List<Flashcard> getDueFlashcards(long documentId, int limit) {
        List<Flashcard> cards = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,front,back,interval_days,repetitions,ease FROM flashcards WHERE document_id=? AND due_at<=? ORDER BY due_at LIMIT ?", new String[]{String.valueOf(documentId),String.valueOf(System.currentTimeMillis()),String.valueOf(limit)})) {
            while(c.moveToNext()) cards.add(new Flashcard(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getInt(4),c.getFloat(5)));
        }
        return cards;
    }

    public void reviewFlashcard(Flashcard card, int grade) {
        int reps = card.repetitions; int interval;
        float ease = card.ease;
        if (grade < 3) { reps = 0; interval = 1; } else { reps++; interval = reps == 1 ? 1 : reps == 2 ? 3 : Math.max(1, Math.round(card.intervalDays * ease)); }
        ease = Math.max(1.3f, ease + (0.1f - (5-grade) * (0.08f + (5-grade) * 0.02f)));
        ContentValues v = new ContentValues(); v.put("due_at",System.currentTimeMillis()+interval*86400000L); v.put("interval_days",interval); v.put("repetitions",reps); v.put("ease",ease); v.put("last_grade",grade);
        getWritableDatabase().update("flashcards",v,"id=?",new String[]{String.valueOf(card.id)});
    }

    public void recordExam(long documentId, String title, int total, int correct) {
        ContentValues v = new ContentValues(); v.put("document_id",documentId); v.put("title",title); v.put("total",total); v.put("correct",correct); v.put("completed_at",System.currentTimeMillis()); getWritableDatabase().insert("exam_sessions",null,v);
    }

    public void recordTopicAttempt(long documentId, String topic, boolean correct) {
        SQLiteDatabase db=getWritableDatabase();
        db.execSQL("UPDATE topic_progress SET attempts=attempts+1, correct=correct+?, updated_at=? WHERE document_id=? AND topic=?",new Object[]{correct?1:0,System.currentTimeMillis(),documentId,topic});
        try (Cursor c=db.rawQuery("SELECT COUNT(*) FROM topic_progress WHERE document_id=? AND topic=?",new String[]{String.valueOf(documentId),topic})) {
            if(c.moveToFirst() && c.getInt(0)==0) { ContentValues v=new ContentValues(); v.put("document_id",documentId); v.put("topic",topic); v.put("attempts",1); v.put("correct",correct?1:0); v.put("updated_at",System.currentTimeMillis()); db.insert("topic_progress",null,v); }
        }
    }

    public String getProgressSummary(long documentId) {
        StringBuilder b=new StringBuilder();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*),COALESCE(SUM(correct),0),COALESCE(SUM(total),0) FROM exam_sessions WHERE document_id=?",new String[]{String.valueOf(documentId)})) { if(c.moveToFirst()) b.append("Exam sessions: ").append(c.getInt(0)).append("\nExam answers correct: ").append(c.getInt(1)).append(" / ").append(c.getInt(2)).append("\n"); }
        try(Cursor c=getReadableDatabase().rawQuery("SELECT topic,attempts,correct FROM topic_progress WHERE document_id=? ORDER BY CAST(correct AS REAL)/MAX(attempts,1) ASC",new String[]{String.valueOf(documentId)})) { while(c.moveToNext()) b.append(c.getString(0)).append(" — ").append(c.getInt(2)).append("/").append(c.getInt(1)).append(" correct\n"); }
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*),SUM(CASE WHEN due_at<=? THEN 1 ELSE 0 END) FROM flashcards WHERE document_id=?",new String[]{String.valueOf(System.currentTimeMillis()),String.valueOf(documentId)})) { if(c.moveToFirst()) b.append("Flashcards: ").append(c.getInt(0)).append(" total, ").append(c.getInt(1)).append(" due now"); }
        return b.toString();
    }

    public static class SearchHit { public final String title,snippet; public final int page; SearchHit(String t,int p,String s){title=t;page=p;snippet=s;} }
    public static class Flashcard { public final long id; public final String front,back; public final int intervalDays,repetitions; public final float ease; Flashcard(long i,String f,String b,int d,int r,float e){id=i;front=f;back=b;intervalDays=d;repetitions=r;ease=e;} }

    public long insertDocument(String title, String filePath, String format, List<String> pages) {
        if (pages == null || pages.isEmpty()) throw new IllegalArgumentException("No readable content found.");
        int words = 0;
        for (String page : pages) words += countWords(page);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        long id = -1;
        try {
            ContentValues document = new ContentValues();
            document.put("title", title);
            document.put("file_path", filePath);
            document.put("format", format);
            document.put("page_count", pages.size());
            document.put("word_count", words);
            document.put("created_at", System.currentTimeMillis());
            id = db.insertOrThrow("documents", null, document);

            for (int i = 0; i < pages.size(); i++) {
                ContentValues page = new ContentValues();
                page.put("document_id", id);
                page.put("page_number", i + 1);
                page.put("content", pages.get(i) == null ? "" : pages.get(i));
                db.insertOrThrow("document_pages", null, page);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return id;
    }

    public List<StudyDocument> getDocuments() {
        List<StudyDocument> result = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query("documents",
                new String[]{"id", "title", "file_path", "format", "page_count", "word_count", "created_at"},
                null, null, null, null, "created_at DESC")) {
            while (c.moveToNext()) result.add(readDocument(c));
        }
        return result;
    }

    public StudyDocument getDocument(long id) {
        try (Cursor c = getReadableDatabase().query("documents",
                new String[]{"id", "title", "file_path", "format", "page_count", "word_count", "created_at"},
                "id=?", new String[]{String.valueOf(id)}, null, null, null)) {
            return c.moveToFirst() ? readDocument(c) : null;
        }
    }

    private StudyDocument readDocument(Cursor c) {
        return new StudyDocument(
                c.getLong(0), c.getString(1), c.getString(2), c.getString(3),
                c.getInt(4), c.getInt(5), c.getLong(6));
    }

    public List<StudyPage> getPages(long documentId, int startPage, int endPage) {
        List<StudyPage> result = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query("document_pages",
                new String[]{"page_number", "content"},
                "document_id=? AND page_number BETWEEN ? AND ?",
                new String[]{String.valueOf(documentId), String.valueOf(startPage), String.valueOf(endPage)},
                null, null, "page_number ASC")) {
            while (c.moveToNext()) result.add(new StudyPage(c.getInt(0), c.getString(1)));
        }
        return result;
    }

    public List<StudyPage> getAllPages(long documentId) {
        return getPages(documentId, 1, Integer.MAX_VALUE);
    }

    public void saveNotes(long documentId, String notes) {
        ContentValues values = new ContentValues();
        values.put("document_id", documentId);
        values.put("notes", notes);
        values.put("updated_at", System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("study_notes", null, values, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public String getNotes(long documentId) {
        try (Cursor c = getReadableDatabase().query("study_notes", new String[]{"notes"},
                "document_id=?", new String[]{String.valueOf(documentId)}, null, null, null)) {
            return c.moveToFirst() ? c.getString(0) : null;
        }
    }

    public void addChatMessage(long documentId, String role, String content) {
        ContentValues values = new ContentValues();
        values.put("document_id", documentId);
        values.put("role", role);
        values.put("content", content);
        values.put("created_at", System.currentTimeMillis());
        getWritableDatabase().insert("chat_messages", null, values);
    }

    public List<ChatMessage> getRecentChat(long documentId, int limit) {
        List<ChatMessage> result = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT role, content, created_at FROM chat_messages WHERE document_id=? ORDER BY id DESC LIMIT ?",
                new String[]{String.valueOf(documentId), String.valueOf(limit)})) {
            while (c.moveToNext()) result.add(new ChatMessage(c.getString(0), c.getString(1), c.getLong(2)));
        }
        Collections.reverse(result);
        return result;
    }

    private static int countWords(String value) {
        if (value == null || value.trim().isEmpty()) return 0;
        String[] parts = value.trim().split("\\s+");
        return parts.length;
    }

    public static class StudyDocument {
        public final long id;
        public final String title;
        public final String filePath;
        public final String format;
        public final int pageCount;
        public final int wordCount;
        public final long createdAt;

        public StudyDocument(long id, String title, String filePath, String format,
                             int pageCount, int wordCount, long createdAt) {
            this.id = id;
            this.title = title;
            this.filePath = filePath;
            this.format = format;
            this.pageCount = pageCount;
            this.wordCount = wordCount;
            this.createdAt = createdAt;
        }
    }

    public static class StudyPage {
        public final int pageNumber;
        public final String content;
        public StudyPage(int pageNumber, String content) {
            this.pageNumber = pageNumber;
            this.content = content == null ? "" : content;
        }
    }

    public static class ChatMessage {
        public final String role;
        public final String content;
        public final long createdAt;
        public ChatMessage(String role, String content, long createdAt) {
            this.role = role;
            this.content = content;
            this.createdAt = createdAt;
        }
    }
}
