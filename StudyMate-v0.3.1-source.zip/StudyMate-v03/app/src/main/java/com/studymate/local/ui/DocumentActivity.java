package com.studymate.local.ui;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.studymate.local.StudyApplication;
import com.studymate.local.ai.LocalLlmEngine;
import com.studymate.local.data.StudyDatabase;
import com.studymate.local.util.ContextBuilder;
import com.studymate.local.util.StudyPrompts;
import android.content.Intent;

import java.util.ArrayList;
import java.util.List;

public class DocumentActivity extends AppCompatActivity {
    public static final String EXTRA_DOCUMENT_ID = "document_id";
    private static final int CHUNK_SIZE = 6800;
    private static final int FINAL_CONTEXT_SIZE = 9500;

    private StudyDatabase database;
    private StudyDatabase.StudyDocument document;
    private LocalLlmEngine ai;
    private EditText fromPageInput;
    private EditText toPageInput;
    private EditText questionInput;
    private TextView statusView;
    private TextView outputView;
    private boolean busy = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        database = StudyDatabase.getInstance(this);
        ai = ((StudyApplication) getApplication()).getLocalLlmEngine();
        long id = getIntent().getLongExtra(EXTRA_DOCUMENT_ID, -1);
        document = database.getDocument(id);
        if (document == null) {
            Toast.makeText(this, "This study material could not be found.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#F5F7F4"));

        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(16), dp(18), dp(30));
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView back = text("‹  Your library", 14, Color.parseColor("#255C4B"), true);
        back.setPadding(0, 0, 0, dp(16));
        back.setOnClickListener(v -> finish());
        body.addView(back, matchWrap());

        addText(body, document.format + "  ·  " + document.pageCount + " page(s)/section(s)",
                10, Color.parseColor("#A06C2C"), true, dp(6));
        addText(body, document.title, 25, Color.parseColor("#19231F"), true, dp(5));
        addText(body, document.wordCount + " words extracted · stored on this device", 12,
                Color.parseColor("#66736D"), false, dp(18));

        MaterialCardView rangeCard = card();
        LinearLayout range = cardColumn(rangeCard);
        addText(range, "CHOOSE YOUR STUDY RANGE", 11, Color.parseColor("#255C4B"), true, dp(6));
        addText(range, "For PDFs this means printed PDF pages. For PowerPoint it means slides. Other imported formats are treated as one or more sections.",
                12, Color.parseColor("#66736D"), false, dp(12));
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.HORIZONTAL);
        fromPageInput = smallInput("From", "1");
        toPageInput = smallInput("To", String.valueOf(document.pageCount));
        fields.addView(fromPageInput, new LinearLayout.LayoutParams(0, dp(54), 1));
        View spacer = new View(this);
        fields.addView(spacer, new LinearLayout.LayoutParams(dp(12), 1));
        fields.addView(toPageInput, new LinearLayout.LayoutParams(0, dp(54), 1));
        range.addView(fields, matchWrap());
        body.addView(rangeCard, matchWrap());

        addSectionHeading(body, "Study tools", "What do you want to do?");
        addAction(body, "Exams, flashcards & progress", "Interactive practice, revision scheduling and weak-topic tracking", () -> {
            Intent intent = new Intent(this, StudyToolsActivity.class);
            intent.putExtra(StudyToolsActivity.EXTRA_DOCUMENT_ID, document.id);
            startActivity(intent);
        });
        addAction(body, "Teach me this range", "A step-by-step lesson with explanations and checkpoints", () -> startChunkedTask("teach"));
        addAction(body, "Make study notes", "Structured notes, key terms and quick revision", () -> startChunkedTask("notes"));
        addAction(body, "Prepare me for the exam", "A study pack with MCQs, short answers and scenarios", () -> startChunkedTask("exam"));

        addSectionHeading(body, "Ask your material", "Ask a question");
        questionInput = new EditText(this);
        questionInput.setHint("Example: Explain the difference between these two concepts…");
        questionInput.setTextSize(14);
        questionInput.setTextColor(Color.parseColor("#19231F"));
        questionInput.setHintTextColor(Color.parseColor("#8A9690"));
        questionInput.setGravity(Gravity.TOP | Gravity.START);
        questionInput.setMinLines(3);
        questionInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        questionInput.setBackgroundColor(Color.WHITE);
        body.addView(questionInput, matchWrap());
        addButton(body, "Ask StudyMate  →", this::askQuestion);

        addSectionHeading(body, "Your output", "Study session");
        statusView = addText(body, ai.isLoaded() ? "Local AI is ready." : "Local AI model not loaded. Open Local AI on the home screen to install one.",
                12, Color.parseColor("#66736D"), false, dp(10));
        MaterialCardView outputCard = card();
        LinearLayout outputBox = cardColumn(outputCard);
        outputView = addText(outputBox, "Your lesson, notes or answers will appear here.",
                14, Color.parseColor("#26342D"), false, 0);
        body.addView(outputCard, matchWrap());

        String savedNotes = database.getNotes(document.id);
        if (savedNotes != null && !savedNotes.trim().isEmpty()) {
            outputView.setText(savedNotes);
            statusView.setText("Saved study notes · generated earlier");
        }

        setContentView(root);
    }

    private void startChunkedTask(String task) {
        if (!ensureReady()) return;
        if (busy) return;
        int[] range = selectedRange();
        if (range == null) return;
        List<StudyDatabase.StudyPage> pages = database.getPages(document.id, range[0], range[1]);
        List<String> chunks = ContextBuilder.makeChunks(pages, CHUNK_SIZE);
        if (chunks.isEmpty()) {
            Toast.makeText(this, "There is no readable text in that page range.", Toast.LENGTH_LONG).show();
            return;
        }
        busy = true;
        outputView.setText("");
        List<String> sectionBriefs = new ArrayList<>();
        statusView.setText("Preparing " + chunks.size() + " source section(s)…");
        runChunk(task, chunks, sectionBriefs, 0, range[0], range[1]);
    }

    private void runChunk(String task, List<String> chunks, List<String> briefs,
                          int index, int from, int to) {
        if (index >= chunks.size()) {
            String merged = ContextBuilder.joinSummaries(briefs, FINAL_CONTEXT_SIZE);
            statusView.setText("Combining source sections into your final " + task + "…");
            String finalPrompt = StudyPrompts.finalPrompt(task, merged, document.title, from, to);
            ai.generate(finalPrompt, new LocalLlmEngine.Callback() {
                @Override public void onSuccess(String result) {
                    runOnUiThread(() -> finishTask(task, result));
                }
                @Override public void onError(String message) {
                    runOnUiThread(() -> failTask(message));
                }
            });
            return;
        }

        statusView.setText("Analysing source section " + (index + 1) + " of " + chunks.size() + "…");
        String prompt = StudyPrompts.chunkPrompt(task, chunks.get(index), index + 1, chunks.size());
        ai.generate(prompt, new LocalLlmEngine.Callback() {
            @Override public void onSuccess(String result) {
                runOnUiThread(() -> {
                    briefs.add(result);
                    runChunk(task, chunks, briefs, index + 1, from, to);
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> failTask("Section " + (index + 1) + " failed: " + message));
            }
        });
    }

    private void finishTask(String task, String result) {
        busy = false;
        outputView.setText(result);
        statusView.setText("Done · generated locally from the selected material.");
        if ("notes".equals(task)) {
            database.saveNotes(document.id, result);
            Toast.makeText(this, "Study notes saved on this phone.", Toast.LENGTH_SHORT).show();
        }
    }

    private void askQuestion() {
        if (!ensureReady()) return;
        if (busy) return;
        String question = questionInput.getText().toString().trim();
        if (question.isEmpty()) {
            questionInput.setError("Write a question first.");
            return;
        }
        int[] range = selectedRange();
        if (range == null) return;
        List<StudyDatabase.StudyPage> pages = database.getPages(document.id, range[0], range[1]);
        List<String> chunks = ContextBuilder.makeChunks(pages, CHUNK_SIZE);
        String context = ContextBuilder.joinSummaries(chunks, FINAL_CONTEXT_SIZE);
        if (context.trim().isEmpty()) {
            Toast.makeText(this, "There is no readable text in that page range.", Toast.LENGTH_LONG).show();
            return;
        }
        String history = ContextBuilder.recentChatAsContext(database.getRecentChat(document.id, 6));
        String prompt = StudyPrompts.questionPrompt(document.title, context, history, question);
        database.addChatMessage(document.id, "user", question);
        busy = true;
        statusView.setText("Thinking on your phone…");
        outputView.setText("Generating answer…");
        ai.generate(prompt, new LocalLlmEngine.Callback() {
            @Override public void onSuccess(String result) {
                runOnUiThread(() -> {
                    busy = false;
                    database.addChatMessage(document.id, "assistant", result);
                    outputView.setText(result);
                    statusView.setText("Answer generated locally. Ask another question when ready.");
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> failTask(message));
            }
        });
        questionInput.setText("");
    }

    private int[] selectedRange() {
        int from;
        int to;
        try {
            from = Integer.parseInt(fromPageInput.getText().toString().trim());
            to = Integer.parseInt(toPageInput.getText().toString().trim());
        } catch (Exception e) {
            fromPageInput.setError("Enter a page/slide number.");
            return null;
        }
        if (from < 1 || to < from || to > document.pageCount) {
            toPageInput.setError("Choose a range from 1 to " + document.pageCount + ".");
            return null;
        }
        return new int[]{from, to};
    }

    private boolean ensureReady() {
        if (ai.isLoaded()) return true;
        Toast.makeText(this, "Load a compatible .litertlm model from the Local AI tab first.", Toast.LENGTH_LONG).show();
        return false;
    }

    private void failTask(String message) {
        busy = false;
        statusView.setText("Could not complete this task.");
        outputView.setText(message);
    }

    private void addAction(LinearLayout parent, String title, String description, Runnable action) {
        MaterialCardView card = card();
        LinearLayout inner = cardColumn(card);
        addText(inner, title, 16, Color.parseColor("#19231F"), true, dp(4));
        addText(inner, description, 12, Color.parseColor("#66736D"), false, dp(9));
        addButton(inner, "Start  →", action);
        parent.addView(card, matchWrap());
        addGap(parent, 9);
    }

    private EditText smallInput(String label, String value) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(value);
        input.setHint(label);
        input.setTextSize(15);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setPadding(dp(12), dp(5), dp(12), dp(5));
        input.setBackgroundColor(Color.parseColor("#F2F5F2"));
        return input;
    }

    private void addSectionHeading(LinearLayout parent, String eyebrow, String heading) {
        addGap(parent, 20);
        addText(parent, eyebrow.toUpperCase(), 10, Color.parseColor("#A06C2C"), true, dp(4));
        addText(parent, heading, 19, Color.parseColor("#19231F"), true, dp(11));
    }

    private MaterialCardView card() {
        MaterialCardView card = new MaterialCardView(this);
        card.setRadius(dp(17));
        card.setCardElevation(dp(1));
        card.setStrokeWidth(dp(1));
        card.setStrokeColor(Color.parseColor("#E2E9E4"));
        card.setCardBackgroundColor(Color.WHITE);
        return card;
    }

    private LinearLayout cardColumn(MaterialCardView card) {
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.addView(inner, new MaterialCardView.LayoutParams(-1, -2));
        return inner;
    }

    private TextView addText(LinearLayout parent, String value, int size, int color,
                             boolean bold, int bottomMargin) {
        TextView view = text(value, size, color, bold);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        if (bottomMargin > 0) params.bottomMargin = bottomMargin;
        parent.addView(view, params);
        return view;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setLineSpacing(dp(3), 1.0f);
        if (bold) view.setTypeface(view.getTypeface(), android.graphics.Typeface.BOLD);
        return view;
    }

    private void addButton(LinearLayout parent, String label, Runnable action) {
        MaterialButton button = new MaterialButton(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setCornerRadius(dp(13));
        button.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(49));
        params.topMargin = dp(5);
        parent.addView(button, params);
    }

    private void addGap(LinearLayout parent, int height) {
        View gap = new View(this);
        parent.addView(gap, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
