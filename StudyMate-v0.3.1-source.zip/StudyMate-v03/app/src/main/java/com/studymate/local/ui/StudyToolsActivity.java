package com.studymate.local.ui;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.studymate.local.StudyApplication;
import com.studymate.local.ai.LocalLlmEngine;
import com.studymate.local.data.StudyDatabase;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Search, spaced-repetition, interactive exams, progress and library tutor. */
public class StudyToolsActivity extends AppCompatActivity {
    public static final String EXTRA_DOCUMENT_ID="document_id";
    private StudyDatabase db; private LocalLlmEngine ai; private long docId=-1;
    private LinearLayout body; private LinearLayout searchResults; private TextView status; private boolean busy;
    private JSONArray exam; private int examIndex,examCorrect; private String examTitle="Practice exam";
    private final List<Integer> answers=new ArrayList<>();
    @Override protected void onCreate(@Nullable Bundle b){super.onCreate(b);db=StudyDatabase.getInstance(this);ai=((StudyApplication)getApplication()).getLocalLlmEngine();docId=getIntent().getLongExtra(EXTRA_DOCUMENT_ID,-1);render();}
    private void render(){ LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(Color.rgb(245,247,244)); ScrollView scroll=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);body.setPadding(40,32,40,48);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
        addText("‹  StudyMate",18,true).setOnClickListener(v->finish()); addText("Study tools",27,true); addText("Search, practise recall, take exams and track what needs work.",14,false);
        status=addText("Local AI: "+(ai.isLoaded()?"ready":"not loaded — load a model in Local AI settings"),12,false);
        section("Search all materials"); EditText search=input("Search a word or phrase across your library"); addButton("Search library",()->search(search.getText().toString())); searchResults=new LinearLayout(this); searchResults.setOrientation(1); body.addView(searchResults);
        section("Flashcards · spaced repetition"); addButton("Generate flashcards from this material",this::generateCards); addButton("Review due flashcards",this::reviewCards);
        section("Interactive exam"); addButton("Generate a 10-question exam",this::generateExam); addButton("View progress and weak topics",this::showProgress);
        section("Ask across your library"); EditText question=input("Ask a question about your uploaded documents"); addButton("Find sources and ask local AI",()->libraryAsk(question.getText().toString()));
    }
    private TextView addText(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(30,45,38));if(bold)t.setTypeface(null,1);t.setPadding(0,8,0,8);body.addView(t);return t;}
    private void section(String s){TextView t=addText(s,17,true);t.setPadding(0,26,0,8);}
    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(14);e.setPadding(24,12,24,12);body.addView(e);return e;}
    private void addButton(String label,Runnable action){MaterialButton b=new MaterialButton(this);b.setText(label);b.setOnClickListener(v->action.run());body.addView(b,new LinearLayout.LayoutParams(-1,-2));}
    private void search(String q){if(q.trim().isEmpty())return;searchResults.removeAllViews();List<StudyDatabase.SearchHit> hits=db.searchLibrary(q,50);TextView heading=new TextView(this);heading.setText("Search results · "+hits.size());heading.setTextSize(17);heading.setTypeface(null,1);searchResults.addView(heading);if(hits.isEmpty()){TextView empty=new TextView(this);empty.setText("No matching passages found. Try a shorter or more specific phrase.");searchResults.addView(empty);}for(StudyDatabase.SearchHit h:hits){TextView item=new TextView(this);item.setText(h.title+" · page/section "+h.page+"\n"+h.snippet);item.setTextSize(13);item.setPadding(0,12,0,12);searchResults.addView(item);}}
    private void generateCards(){if(!ready())return;List<StudyDatabase.StudyDocument> docs=db.getDocuments();if(docs.isEmpty()){toast("Import study material first.");return;}StudyDatabase.StudyDocument d=chooseDoc(docs);if(d==null)return;String source=sourceFor(d.id);if(source.isEmpty())return;runAi("Create 15 concise flashcards from this source. Return ONLY a JSON array of objects with keys front and back. No markdown. Keep answers factual. SOURCE:\n"+source, result->{try{JSONArray a=new JSONArray(cleanJson(result));int n=0;for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);String f=o.optString("front"),b=o.optString("back");if(!f.isEmpty()&&!b.isEmpty()){if(db.addFlashcard(d.id,f,b))n++;}}toast(n+" flashcards saved.");}catch(Exception e){toast("Could not read flashcard output. Try a smaller source range.");}});}
    private void reviewCards(){List<StudyDatabase.StudyDocument> docs=db.getDocuments();StudyDatabase.StudyDocument d=chooseDoc(docs);if(d==null)return;List<StudyDatabase.Flashcard> cards=db.getDueFlashcards(d.id,100);if(cards.isEmpty()){toast("No cards due. Generate cards or review later.");return;}reviewAt(d.id,cards,0);}
    private void reviewAt(long id,List<StudyDatabase.Flashcard> cards,int ix){if(ix>=cards.size()){toast("Review complete.");return;}StudyDatabase.Flashcard c=cards.get(ix);new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Card "+(ix+1)+" / "+cards.size()).setMessage(c.front).setPositiveButton("Show answer",(x,w)->new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Answer").setMessage(c.back).setNeutralButton("Again",(a,z)->{db.reviewFlashcard(c,1);reviewAt(id,cards,ix+1);}).setNegativeButton("Hard",(a,z)->{db.reviewFlashcard(c,3);reviewAt(id,cards,ix+1);}).setPositiveButton("Know it",(a,z)->{db.reviewFlashcard(c,5);reviewAt(id,cards,ix+1);}).show()).setNegativeButton("Stop",null).show();}
    private void generateExam(){if(!ready())return;StudyDatabase.StudyDocument d=chooseDoc(db.getDocuments());if(d==null)return;String src=sourceFor(d.id);runAi("Create exactly 10 exam questions based only on this source. Return ONLY JSON array. Each object: question (string), options (array of exactly 4 strings), answer (zero-based integer), topic (short string), explanation (one-sentence reason). Mix recall and application. SOURCE:\n"+src,r->{try{exam=new JSONArray(cleanJson(r));if(exam.length()!=10)throw new Exception("Expected 10 questions, received "+exam.length());for(int i=0;i<exam.length();i++){JSONObject item=exam.getJSONObject(i);JSONArray options=item.getJSONArray("options");int answer=item.getInt("answer");if(item.optString("question").trim().isEmpty()||options.length()!=4||answer<0||answer>=4)throw new Exception("Invalid question "+(i+1));for(int j=0;j<4;j++)if(options.optString(j).trim().isEmpty())throw new Exception("Empty option");}examTitle=d.title+" practice";examIndex=0;examCorrect=0;answers.clear();takeQuestion(d.id);}catch(Exception e){toast("Exam output was not valid JSON. Try again with fewer pages.");}});}
    private void takeQuestion(long id){if(examIndex>=exam.length()){db.recordExam(id,examTitle,exam.length(),examCorrect);showResult();return;}try{JSONObject q=exam.getJSONObject(examIndex);JSONArray opts=q.getJSONArray("options");String[] labels=new String[opts.length()];for(int i=0;i<opts.length();i++)labels[i]=opts.getString(i);final int[] selected={-1};new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Question "+(examIndex+1)+" / "+exam.length()).setMessage(q.getString("question")).setSingleChoiceItems(labels,-1,(dialog,which)->selected[0]=which).setPositiveButton("Submit",(dialog,w)->{if(selected[0]<0){toast("Select an answer before submitting.");takeQuestion(id);return;}int correct=q.getInt("answer");boolean ok=selected[0]==correct;if(ok)examCorrect++;db.recordTopicAttempt(id,q.optString("topic","General"),ok);String feedback=ok?"Correct. "+q.optString("explanation", "You selected the keyed answer."):"Not quite. Correct answer: "+labels[correct]+". "+q.optString("explanation", "Review this topic in your source material.");new androidx.appcompat.app.AlertDialog.Builder(this).setMessage(feedback).setPositiveButton("Next",(a,b)->{examIndex++;takeQuestion(id);}).show();}).setNegativeButton("Exit",null).show();}catch(Exception e){toast("Could not display this question.");}}
    private void showResult(){new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Exam complete").setMessage("Score: "+examCorrect+" / "+exam.length()+" ("+(100*examCorrect/exam.length())+"%)").setPositiveButton("OK",null).show();}
    private void showProgress(){List<StudyDatabase.StudyDocument> docs=db.getDocuments();StudyDatabase.StudyDocument d=chooseDoc(docs);if(d==null)return;new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Progress · "+d.title).setMessage(db.getProgressSummary(d.id)+"\n\nTopics with the lowest accuracy appear first. A topic needs repeated attempts before the percentage is meaningful.").setPositiveButton("OK",null).show();}
    private void libraryAsk(String q){if(!ready())return;if(q.trim().isEmpty())return;List<StudyDatabase.SearchHit> hits=db.searchLibrary(q,8);if(hits.isEmpty()){toast("No exact text match found. Try a shorter keyword.");return;}StringBuilder context=new StringBuilder();for(StudyDatabase.SearchHit h:hits)context.append("[SOURCE: ").append(h.title).append(", page ").append(h.page).append("]\n").append(h.snippet).append("\n\n");runAi("Answer the student's question using only these retrieved passages. Cite every factual claim with [Document, page N]. If evidence is insufficient, say so. QUESTION: "+q+"\nPASSAGES:\n"+context,r->addText("Tutor answer\n"+r,14,false));}
    private String sourceFor(long id){StringBuilder b=new StringBuilder();for(StudyDatabase.StudyPage p:db.getAllPages(id)){if(b.length()>18000)break;b.append("[Page ").append(p.pageNumber).append("] ").append(p.content).append("\n");}return b.toString();}
    private StudyDatabase.StudyDocument chooseDoc(List<StudyDatabase.StudyDocument> docs){if(docs==null||docs.isEmpty()){toast("Import a document first.");return null;}if(docId>0){StudyDatabase.StudyDocument d=db.getDocument(docId);if(d!=null)return d;}return docs.get(0);}
    private boolean ready(){if(busy)return false;if(!ai.isLoaded()){toast("Load a local AI model first.");return false;}return true;}
    private interface Result{void done(String s);}private void runAi(String prompt,Result cb){busy=true;status.setText("Working locally…");ai.generate(prompt,new LocalLlmEngine.Callback(){public void onSuccess(String s){runOnUiThread(()->{busy=false;status.setText("Local AI ready");cb.done(s);});}public void onError(String m){runOnUiThread(()->{busy=false;status.setText(m);toast(m);});}});}
    private String cleanJson(String s){String x=s.trim();int a=x.indexOf('['),b=x.lastIndexOf(']');if(a>=0&&b>a)x=x.substring(a,b+1);return x;}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
