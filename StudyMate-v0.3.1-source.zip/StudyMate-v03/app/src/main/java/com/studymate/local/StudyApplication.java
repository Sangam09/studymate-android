package com.studymate.local;

import android.app.Application;

import com.studymate.local.ai.LocalLlmEngine;

public class StudyApplication extends Application {
    private LocalLlmEngine localLlmEngine;

    @Override
    public void onCreate() {
        super.onCreate();
        localLlmEngine = new LocalLlmEngine(this);
    }

    public LocalLlmEngine getLocalLlmEngine() {
        return localLlmEngine;
    }
}
