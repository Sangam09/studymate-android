package com.studymate.local.importer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.text.Html;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import org.xmlpull.v1.XmlPullParser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import android.util.Xml;

public class StudyImporter {
    private static final long MAX_FILE_BYTES = 250L * 1024L * 1024L;
    private static final int MAX_TEXT_CHARS = 18_000_000;
    private static final int MAX_PAGE_CHARS = 500_000;
    private static final int MAX_PDF_PAGES = 1200;
    private static final int MAX_SECTIONS = 1200;

    public ImportResult importDocument(Context context, Uri sourceUri, String originalName) throws Exception {
        String safeName = sanitizeName(originalName == null ? "study-material" : originalName);
        String extension = extensionOf(safeName);
        if (!isSupported(extension)) {
            throw new IOException("Unsupported file type: ." + extension + ". Supported: PDF, DOCX, PPTX, ODT, TXT, MD, CSV, HTML, RTF and EPUB.");
        }

        File directory = new File(context.getFilesDir(), "materials");
        if (!directory.exists() && !directory.mkdirs()) throw new IOException("Cannot create private materials folder.");
        File destination = new File(directory, UUID.randomUUID().toString() + "_" + safeName);
        try {
            copyUri(context, sourceUri, destination);
        } catch (Exception e) {
            //noinspection ResultOfMethodCallIgnored
            destination.delete();
            throw e;
        }

        List<String> pages;
        try {
            switch (extension) {
                case "pdf": pages = extractPdf(context, destination); break;
                case "docx": pages = singleton(extractOfficeXml(destination, "word/document.xml")); break;
                case "pptx": pages = extractPowerPoint(destination); break;
                case "odt": pages = singleton(extractOfficeXml(destination, "content.xml")); break;
                case "epub": pages = extractEpub(destination); break;
                case "html": pages = singleton(htmlToText(readFile(destination))); break;
                case "rtf": pages = singleton(rtfToText(readFile(destination))); break;
                default: pages = singleton(readFile(destination)); break;
            }
        } catch (Exception e) {
            // Keep the private copy only when parsing succeeded. Avoid leaving unusable imports behind.
            // File deletion is best effort; the original source is never modified.
            //noinspection ResultOfMethodCallIgnored
            destination.delete();
            throw e;
        }

        List<String> cleaned = new ArrayList<>();
        int remainingDocumentCharacters = MAX_TEXT_CHARS;
        for (String page : pages) {
            if (remainingDocumentCharacters <= 0) break;
            String value = page == null ? "" : page.trim();
            int allowed = Math.min(MAX_PAGE_CHARS, remainingDocumentCharacters);
            if (value.length() > allowed) value = value.substring(0, allowed);
            cleaned.add(value);
            remainingDocumentCharacters -= value.length();
        }
        boolean hasText = false;
        for (String value : cleaned) if (!value.trim().isEmpty()) { hasText = true; break; }
        if (!hasText) {
            //noinspection ResultOfMethodCallIgnored
            destination.delete();
            throw new IOException("No readable text was found. The file may be blank, protected, or image-only.");
        }
        return new ImportResult(destination, safeName, extension.toUpperCase(Locale.ROOT), cleaned);
    }

    private void copyUri(Context context, Uri uri, File destination) throws IOException {
        long total = 0;
        try (InputStream in = context.getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(destination)) {
            if (in == null) throw new IOException("Android could not open the selected file.");
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                total += read;
                if (total > MAX_FILE_BYTES) throw new IOException("File is larger than the 250 MB import limit.");
                out.write(buffer, 0, read);
            }
            out.flush();
        }
    }

    private List<String> extractPdf(Context context, File file) throws Exception {
        PDFBoxResourceLoader.init(context.getApplicationContext());
        List<String> pages = new ArrayList<>();
        try (PDDocument document = PDDocument.load(file)) {
            int pageCount = document.getNumberOfPages();
            if (pageCount > MAX_PDF_PAGES) throw new IOException("This first build supports PDFs up to " + MAX_PDF_PAGES + " pages.");
            PDFTextStripper stripper = new PDFTextStripper();
            for (int page = 1; page <= pageCount; page++) {
                stripper.setStartPage(page);
                stripper.setEndPage(page);
                String pageText = stripper.getText(document);
                if (pageText != null && pageText.length() > MAX_PAGE_CHARS) pageText = pageText.substring(0, MAX_PAGE_CHARS);
                pages.add(pageText == null ? "" : pageText);
            }
        }

        boolean needsOcr = false;
        for (String text : pages) if (text == null || text.trim().length() < 12) { needsOcr = true; break; }
        if (needsOcr) runOcrOnEmptyPdfPages(file, pages);
        return pages;
    }

    /** Uses on-device ML Kit OCR only for pages where PDF text extraction found almost nothing. */
    private void runOcrOnEmptyPdfPages(File file, List<String> pages) {
        com.google.mlkit.vision.text.TextRecognizer recognizer = null;
        com.google.mlkit.vision.text.TextRecognizer devanagariRecognizer = null;
        try (ParcelFileDescriptor descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer renderer = new PdfRenderer(descriptor)) {
            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            devanagariRecognizer = TextRecognition.getClient(new DevanagariTextRecognizerOptions.Builder().build());
            int count = Math.min(renderer.getPageCount(), pages.size());
            for (int i = 0; i < count; i++) {
                if (pages.get(i) != null && pages.get(i).trim().length() >= 12) continue;
                PdfRenderer.Page page = renderer.openPage(i);
                Bitmap bitmap = null;
                try {
                    float scale = Math.min(2.0f, 1800f / Math.max(page.getWidth(), page.getHeight()));
                    int width = Math.max(1, (int) (page.getWidth() * scale));
                    int height = Math.max(1, (int) (page.getHeight() * scale));
                    bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    Text result = Tasks.await(
                            recognizer.process(InputImage.fromBitmap(bitmap, 0)),
                            45, TimeUnit.SECONDS);
                    String detected = result == null ? "" : result.getText();
                    Text devanagariResult = Tasks.await(
                            devanagariRecognizer.process(InputImage.fromBitmap(bitmap, 0)),
                            45, TimeUnit.SECONDS);
                    String devanagari = devanagariResult == null ? "" : devanagariResult.getText();
                    String combined = detected == null ? "" : detected.trim();
                    if (devanagari != null && devanagari.matches("(?s).*\\p{InDevanagari}.*")) {
                        combined = devanagari.trim() + (combined.isEmpty() ? "" : "\n" + combined);
                    }
                    if (!combined.isEmpty()) pages.set(i, combined);
                } catch (Exception ignored) {
                    // A page can fail OCR without preventing the rest of the PDF from being imported.
                } finally {
                    if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                    page.close();
                }
            }
        } catch (Exception ignored) {
            // If Google Play services/OCR is unavailable, retain the text extracted by PDFBox.
        } finally {
            if (recognizer != null) recognizer.close();
            if (devanagariRecognizer != null) devanagariRecognizer.close();
        }
    }

    private String extractOfficeXml(File file, String entryName) throws Exception {
        try (ZipFile zip = new ZipFile(file)) {
            ZipEntry entry = zip.getEntry(entryName);
            if (entry == null) throw new IOException("The Office file is missing " + entryName + ". It may be damaged.");
            try (InputStream in = zip.getInputStream(entry)) {
                return xmlToText(in);
            }
        }
    }

    private List<String> extractPowerPoint(File file) throws Exception {
        List<ZipEntry> slideEntries = new ArrayList<>();
        try (ZipFile zip = new ZipFile(file)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                String name = entry.getName();
                if (name.matches("ppt/slides/slide[0-9]+\\.xml")) {
                    if (slideEntries.size() >= MAX_SECTIONS) throw new IOException("This first build supports up to " + MAX_SECTIONS + " slides/sections.");
                    slideEntries.add(entry);
                }
            }
            Collections.sort(slideEntries, Comparator.comparingInt(e -> slideNumber(e.getName())));
            List<String> slides = new ArrayList<>();
            for (ZipEntry entry : slideEntries) {
                try (InputStream in = zip.getInputStream(entry)) {
                    slides.add("SLIDE " + slideNumber(entry.getName()) + "\n" + xmlToText(in));
                }
            }
            if (slides.isEmpty()) throw new IOException("No PowerPoint slides were found.");
            return slides;
        }
    }

    private List<String> extractEpub(File file) throws Exception {
        List<String> chapterNames = new ArrayList<>();
        try (ZipFile zip = new ZipFile(file)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                String name = entry.getName().toLowerCase(Locale.ROOT);
                if (!entry.isDirectory() && (name.endsWith(".xhtml") || name.endsWith(".html") || name.endsWith(".htm"))) {
                    if (chapterNames.size() >= MAX_SECTIONS) throw new IOException("This EPUB contains more than " + MAX_SECTIONS + " HTML sections.");
                    chapterNames.add(entry.getName());
                }
            }
            Collections.sort(chapterNames);
            List<String> chapters = new ArrayList<>();
            for (String name : chapterNames) {
                ZipEntry entry = zip.getEntry(name);
                try (InputStream in = zip.getInputStream(entry)) {
                    String raw = readStream(in, 2_000_000);
                    String text = htmlToText(raw).trim();
                    if (!text.isEmpty()) chapters.add(text);
                }
            }
            if (chapters.isEmpty()) throw new IOException("No readable EPUB chapter files were found.");
            return chapters;
        }
    }

    private String xmlToText(InputStream in) throws Exception {
        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(in, "UTF-8");
        StringBuilder out = new StringBuilder();
        int event;
        while ((event = parser.next()) != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.TEXT) {
                String text = parser.getText();
                if (text != null && !text.trim().isEmpty()) {
                    if (out.length() > 0) out.append(' ');
                    out.append(text.trim());
                }
            } else if (event == XmlPullParser.END_TAG && "p".equals(parser.getName())) {
                out.append('\n');
            }
            if (out.length() > MAX_PAGE_CHARS) break;
        }
        return out.toString();
    }

    private String readFile(File file) throws IOException {
        try (InputStream in = new java.io.FileInputStream(file)) {
            return readStream(in, MAX_TEXT_CHARS);
        }
    }

    private String readStream(InputStream in, int maxChars) throws IOException {
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buffer = new char[8192];
            int read;
            while ((read = reader.read(buffer)) != -1) {
                int remaining = maxChars - out.length();
                if (remaining <= 0) break;
                out.append(buffer, 0, Math.min(read, remaining));
            }
        }
        return out.toString();
    }

    private String htmlToText(String html) {
        if (android.os.Build.VERSION.SDK_INT >= 24) {
            return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString();
        }
        //noinspection deprecation
        return Html.fromHtml(html).toString();
    }

    private String rtfToText(String rtf) {
        return rtf.replaceAll("(?s)\\\\'[0-9a-fA-F]{2}", "")
                .replaceAll("\\\\(par|line)\\b", "\n")
                .replaceAll("\\\\tab\\b", "\t")
                .replaceAll("\\\\[a-zA-Z]+-?\\d* ?", "")
                .replaceAll("[{}]", "")
                .trim();
    }

    private int slideNumber(String name) {
        String digits = name.replaceAll("[^0-9]", "");
        try { return Integer.parseInt(digits); } catch (Exception e) { return 0; }
    }

    private List<String> singleton(String content) {
        List<String> one = new ArrayList<>();
        one.add(content == null ? "" : content);
        return one;
    }

    private boolean isSupported(String extension) {
        switch (extension) {
            case "pdf": case "docx": case "pptx": case "odt": case "txt":
            case "md": case "markdown": case "csv": case "html": case "htm":
            case "rtf": case "epub": return true;
            default: return false;
        }
    }

    private String extensionOf(String name) {
        int dot = name.lastIndexOf('.');
        return dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    private String sanitizeName(String name) {
        String cleaned = name.replace('/', '_').replace('\\', '_').replaceAll("[^A-Za-z0-9._ -]", "_").trim();
        return cleaned.isEmpty() ? "study-material.txt" : cleaned;
    }

    public static class ImportResult {
        public final File file;
        public final String displayName;
        public final String format;
        public final List<String> pages;
        public ImportResult(File file, String displayName, String format, List<String> pages) {
            this.file = file;
            this.displayName = displayName;
            this.format = format;
            this.pages = pages;
        }
    }
}
