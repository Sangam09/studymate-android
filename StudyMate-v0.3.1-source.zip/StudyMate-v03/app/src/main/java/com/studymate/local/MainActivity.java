package com.studymate.local;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.studymate.local.ai.LocalLlmEngine;
import com.studymate.local.data.StudyDatabase;
import com.studymate.local.importer.StudyImporter;
import com.studymate.local.ui.DocumentActivity;
import com.studymate.local.ui.StudyToolsActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static final int PICK_MATERIAL = 401;
    private static final int PICK_MODEL = 402;
    private static final String PREFS = "studymate_settings";
    private static final String PREF_MODEL_PATH = "local_model_path";

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private StudyDatabase database;
    private LinearLayout content;
    private TextView modelState;
    private int selectedTab = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        database = StudyDatabase.getInstance(this);
        renderScreen();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdown();
    }

    private void renderScreen() {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(Color.parseColor("#F5F7F4"));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(18), dp(20), dp(24));
        scroll.addView(content);
        shell.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout navigation = new LinearLayout(this);
        navigation.setOrientation(LinearLayout.HORIZONTAL);
        navigation.setGravity(Gravity.CENTER);
        navigation.setPadding(dp(10), dp(8), dp(10), dp(8));
        navigation.setBackgroundColor(Color.WHITE);
        navigation.addView(navButton("Home", 0), new LinearLayout.LayoutParams(0, dp(48), 1));
        navigation.addView(navButton("Library", 1), new LinearLayout.LayoutParams(0, dp(48), 1));
        navigation.addView(navButton("Local AI", 2), new LinearLayout.LayoutParams(0, dp(48), 1));
        shell.addView(navigation, new LinearLayout.LayoutParams(-1, dp(64)));
        setContentView(shell);

        if (selectedTab == 1) renderLibrary();
        else if (selectedTab == 2) renderAiSettings();
        else renderHome();
    }

    private MaterialButton navButton(String label, int tab) {
        MaterialButton button = new MaterialButton(this);
        button.setText(label);
        button.setTextSize(12);
        button.setInsetTop(0);
        button.setInsetBottom(0);
        button.setCornerRadius(dp(14));
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                selectedTab == tab ? Color.parseColor("#255C4B") : Color.WHITE));
        button.setTextColor(selectedTab == tab ? Color.WHITE : Color.parseColor("#52625B"));
        button.setOnClickListener(v -> {
            selectedTab = tab;
            renderScreen();
        });
        return button;
    }

    private void renderHome() {
        content.removeAllViews();
        addBrandHeader();
        addText(content, "Your study space", 27, Color.parseColor("#19231F"), true, dp(20));
        addText(content, "Turn your class materials into notes, lessons and exam practice.", 14,
                Color.parseColor("#66736D"), false, dp(18));

        MaterialCardView importCard = card();
        LinearLayout inner = cardColumn(importCard);
        addText(inner, "01  ·  ADD MATERIAL", 11, Color.parseColor("#255C4B"), true, dp(8));
        addText(inner, "Bring your notes into one place", 19, Color.parseColor("#19231F"), true, dp(6));
        addText(inner, "Import PDF, Word, PowerPoint, text files and more. StudyMate extracts the content and keeps it on this phone.",
                13, Color.parseColor("#66736D"), false, dp(12));
        addButton(inner, "＋  Import study material", this::chooseMaterial);
        content.addView(importCard, matchWrap());
        addGap(content, 14);

        MaterialCardView aiCard = card();
        LinearLayout aiInner = cardColumn(aiCard);
        addText(aiInner, "02  ·  PRIVATE AI", 11, Color.parseColor("#A06C2C"), true, dp(8));
        addText(aiInner, "Run your tutor on your phone", 19, Color.parseColor("#19231F"), true, dp(6));
        addText(aiInner, "Choose a compatible .litertlm model once. After it is installed, study questions and answers are generated locally without a per-question API fee.",
                13, Color.parseColor("#66736D"), false, dp(12));
        addButton(aiInner, "Set up local AI model", () -> { selectedTab = 2; renderScreen(); });
        content.addView(aiCard, matchWrap());
        addGap(content, 14);
        MaterialCardView toolsCard = card();
        LinearLayout toolsInner = cardColumn(toolsCard);
        addText(toolsInner, "03  ·  EXAM & REVISION", 11, Color.parseColor("#255C4B"), true, dp(8));
        addText(toolsInner, "Practise, search and track progress", 19, Color.parseColor("#19231F"), true, dp(6));
        addText(toolsInner, "Interactive exams, spaced-repetition flashcards, full-library search and weak-topic tracking.", 13, Color.parseColor("#66736D"), false, dp(12));
        addButton(toolsInner, "Open study tools", () -> startActivity(new Intent(this, StudyToolsActivity.class)));
        content.addView(toolsCard, matchWrap());

        addSectionHeading(content, "Recently added", "Your study materials");
        List<StudyDatabase.StudyDocument> documents = database.getDocuments();
        if (documents.isEmpty()) {
            addEmptyState(content, "No materials yet", "Import a PDF or class file to start your first study space.");
        } else {
            int count = Math.min(4, documents.size());
            for (int i = 0; i < count; i++) addDocumentCard(content, documents.get(i));
            if (documents.size() > count) addText(content, "Open Library to see all " + documents.size() + " materials.",
                    12, Color.parseColor("#66736D"), false, dp(10));
        }
    }

    private void renderLibrary() {
        content.removeAllViews();
        addBrandHeader();
        addText(content, "Your library", 27, Color.parseColor("#19231F"), true, dp(8));
        addText(content, "Each imported file is copied to private storage and indexed for page-based study.",
                13, Color.parseColor("#66736D"), false, dp(18));
        addButton(content, "＋  Import another file", this::chooseMaterial);
        addGap(content, 10);
        List<StudyDatabase.StudyDocument> documents = database.getDocuments();
        if (documents.isEmpty()) addEmptyState(content, "Your library is empty", "Use the import button to add your first material.");
        else for (StudyDatabase.StudyDocument document : documents) addDocumentCard(content, document);
    }

    private void renderAiSettings() {
        content.removeAllViews();
        addBrandHeader();
        addText(content, "Local AI setup", 27, Color.parseColor("#19231F"), true, dp(8));
        addText(content, "The language model runs on the phone. StudyMate does not send your document text to a cloud AI service.",
                13, Color.parseColor("#66736D"), false, dp(18));

        MaterialCardView statusCard = card();
        LinearLayout inner = cardColumn(statusCard);
        addText(inner, "MODEL STATUS", 11, Color.parseColor("#255C4B"), true, dp(8));
        modelState = addText(inner, modelStatusText(), 15, Color.parseColor("#19231F"), true, dp(12));
        addButton(inner, "Choose .litertlm model file", this::chooseModel);
        addButton(inner, "Load saved model", this::loadSavedModel);
        content.addView(statusCard, matchWrap());

        addSectionHeading(content, "Model setup", "What you need");
        addBullet(content, "Download a model in LiteRT-LM .litertlm format from the LiteRT Community model collection.");
        addBullet(content, "Choose the downloaded file above. StudyMate copies it into the app's private model folder.");
        addBullet(content, "The first load can take several seconds. Model files may be hundreds of MB or multiple GB.");
        addButton(content, "Browse LiteRT Community models", () -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://huggingface.co/litert-community")));
            } catch (Exception e) {
                Toast.makeText(this, "Could not open the model collection.", Toast.LENGTH_SHORT).show();
            }
        });
        addGap(content, 16);
        addText(content, "Important: local does not mean limitless. There is no per-request API charge, but model size, context length, RAM, heat, battery and phone speed still set practical limits. This first build uses the CPU backend for compatibility.",
                12, Color.parseColor("#66736D"), false, dp(12));
    }

    private String modelStatusText() {
        if (((StudyApplication) getApplication()).getLocalLlmEngine().isLoaded()) return "Ready · local model loaded";
        String path = getPreferences(MODE_PRIVATE).getString(PREF_MODEL_PATH, null);
        if (path == null) return "No model selected yet";
        File file = new File(path);
        return file.exists() ? "Model file installed · load it to start" : "Saved model file is missing. Choose it again.";
    }

    private void chooseMaterial() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/pdf",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                "application/vnd.oasis.opendocument.text",
                "text/plain", "text/markdown", "text/csv", "text/html", "application/rtf", "application/epub+zip"
        });
        startActivityForResult(intent, PICK_MATERIAL);
    }

    private void chooseModel() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_MODEL);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String name = getDisplayName(uri);
        if (requestCode == PICK_MATERIAL) importMaterial(uri, name);
        else if (requestCode == PICK_MODEL) installAndLoadModel(uri, name);
    }

    private void importMaterial(Uri uri, String name) {
        Toast.makeText(this, "Importing and analysing file…", Toast.LENGTH_SHORT).show();
        io.execute(() -> {
            try {
                StudyImporter.ImportResult imported = new StudyImporter().importDocument(getApplicationContext(), uri, name);
                long id = database.insertDocument(imported.displayName, imported.file.getAbsolutePath(),
                        imported.format, imported.pages);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Material added · " + imported.pages.size() + " pages/sections", Toast.LENGTH_LONG).show();
                    openDocument(id);
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this,
                        "Import failed: " + (e.getMessage() == null ? "Could not read this file." : e.getMessage()),
                        Toast.LENGTH_LONG).show());
            }
        });
    }

    private void installAndLoadModel(Uri uri, String name) {
        if (name == null || !name.toLowerCase().endsWith(".litertlm")) {
            Toast.makeText(this, "Choose a LiteRT-LM model file ending in .litertlm.", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Copying model to private app storage…", Toast.LENGTH_SHORT).show();
        io.execute(() -> {
            try {
                File folder = new File(getFilesDir(), "models");
                if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Could not create model folder.");
                File destination = new File(folder, "studymate-model.litertlm");
                try (InputStream in = getContentResolver().openInputStream(uri);
                     FileOutputStream out = new FileOutputStream(destination)) {
                    if (in == null) throw new IllegalStateException("Could not open model file.");
                    byte[] buffer = new byte[1024 * 1024];
                    int read;
                    while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                    out.flush();
                }
                getPreferences(MODE_PRIVATE).edit().putString(PREF_MODEL_PATH, destination.getAbsolutePath()).apply();
                runOnUiThread(() -> loadModelFile(destination));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Model import failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void loadSavedModel() {
        String path = getPreferences(MODE_PRIVATE).getString(PREF_MODEL_PATH, null);
        if (path == null) {
            Toast.makeText(this, "Choose a .litertlm model file first.", Toast.LENGTH_SHORT).show();
            return;
        }
        File file = new File(path);
        if (!file.exists()) {
            Toast.makeText(this, "The saved model file is missing. Choose it again.", Toast.LENGTH_LONG).show();
            return;
        }
        loadModelFile(file);
    }

    private void loadModelFile(File file) {
        if (modelState != null) modelState.setText("Loading model… first load may take a while.");
        Toast.makeText(this, "Loading local AI model…", Toast.LENGTH_LONG).show();
        ((StudyApplication) getApplication()).getLocalLlmEngine().loadModel(file.getAbsolutePath(), new LocalLlmEngine.Callback() {
            @Override public void onSuccess(String message) {
                runOnUiThread(() -> {
                    if (modelState != null) modelState.setText("Ready · local model loaded");
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    if (modelState != null) modelState.setText("Model load failed: " + message);
                    Toast.makeText(MainActivity.this, "Model load failed: " + message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private String getDisplayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {}
        String segment = uri.getLastPathSegment();
        return segment == null ? "study-material.txt" : segment;
    }

    private void openDocument(long id) {
        Intent intent = new Intent(this, DocumentActivity.class);
        intent.putExtra(DocumentActivity.EXTRA_DOCUMENT_ID, id);
        startActivity(intent);
    }

    private void addBrandHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = new TextView(this);
        mark.setText("S");
        mark.setTextSize(17);
        mark.setTextColor(Color.WHITE);
        mark.setTypeface(mark.getTypeface(), android.graphics.Typeface.BOLD);
        mark.setGravity(Gravity.CENTER);
        mark.setBackgroundColor(Color.parseColor("#255C4B"));
        row.addView(mark, new LinearLayout.LayoutParams(dp(38), dp(38)));
        addHorizontalGap(row, 10);
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        addText(brand, "STUDYMATE", 14, Color.parseColor("#19231F"), true, 0);
        addText(brand, "LOCAL AI STUDY SPACE", 9, Color.parseColor("#66736D"), true, 0);
        row.addView(brand, new LinearLayout.LayoutParams(-2, -2));
        content.addView(row, matchWrap());
        addGap(content, 22);
    }

    private void addDocumentCard(LinearLayout parent, StudyDatabase.StudyDocument document) {
        MaterialCardView card = card();
        LinearLayout inner = cardColumn(card);
        addText(inner, document.format + "  ·  " + document.pageCount + " page(s)/section(s)",
                10, Color.parseColor("#255C4B"), true, dp(6));
        addText(inner, document.title, 16, Color.parseColor("#19231F"), true, dp(4));
        addText(inner, document.wordCount + " words extracted", 12, Color.parseColor("#66736D"), false, dp(10));
        addButton(inner, "Open study room  →", () -> openDocument(document.id));
        parent.addView(card, matchWrap());
        addGap(parent, 10);
    }

    private void addEmptyState(LinearLayout parent, String title, String detail) {
        MaterialCardView card = card();
        LinearLayout inner = cardColumn(card);
        addText(inner, title, 17, Color.parseColor("#19231F"), true, dp(6));
        addText(inner, detail, 13, Color.parseColor("#66736D"), false, 0);
        parent.addView(card, matchWrap());
    }

    private void addSectionHeading(LinearLayout parent, String eyebrow, String heading) {
        addGap(parent, 22);
        addText(parent, eyebrow.toUpperCase(), 10, Color.parseColor("#A06C2C"), true, dp(4));
        addText(parent, heading, 19, Color.parseColor("#19231F"), true, dp(10));
    }

    private void addBullet(LinearLayout parent, String text) {
        TextView bullet = addText(parent, "•  " + text, 13, Color.parseColor("#52625B"), false, dp(12));
        bullet.setPadding(dp(4), dp(4), dp(4), dp(4));
    }

    private MaterialCardView card() {
        MaterialCardView card = new MaterialCardView(this);
        card.setRadius(dp(18));
        card.setCardElevation(dp(1));
        card.setStrokeWidth(dp(1));
        card.setStrokeColor(Color.parseColor("#E2E9E4"));
        card.setCardBackgroundColor(Color.WHITE);
        return card;
    }

    private LinearLayout cardColumn(MaterialCardView card) {
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.addView(inner, new MaterialCardView.LayoutParams(-1, -2));
        return inner;
    }

    private TextView addText(LinearLayout parent, String text, int size, int color, boolean bold, int bottomMargin) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setLineSpacing(dp(2), 1.0f);
        if (bold) view.setTypeface(view.getTypeface(), android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        if (bottomMargin > 0) params.bottomMargin = bottomMargin;
        parent.addView(view, params);
        return view;
    }

    private void addButton(LinearLayout parent, String label, Runnable action) {
        MaterialButton button = new MaterialButton(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setCornerRadius(dp(13));
        button.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(50));
        params.topMargin = dp(5);
        parent.addView(button, params);
    }

    private void addGap(LinearLayout parent, int height) {
        View gap = new View(this);
        parent.addView(gap, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private void addHorizontalGap(LinearLayout parent, int width) {
        View gap = new View(this);
        parent.addView(gap, new LinearLayout.LayoutParams(dp(width), 1));
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
