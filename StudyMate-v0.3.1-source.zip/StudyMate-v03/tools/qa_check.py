#!/usr/bin/env python3
"""Offline structural QA for StudyMate. This is not a substitute for Android Gradle/device tests."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
required = [
    'app/src/main/AndroidManifest.xml',
    'app/src/main/java/com/studymate/local/MainActivity.java',
    'app/src/main/java/com/studymate/local/data/StudyDatabase.java',
    'app/src/main/java/com/studymate/local/importer/StudyImporter.java',
    'app/src/main/java/com/studymate/local/ui/DocumentActivity.java',
    'app/src/main/java/com/studymate/local/ui/StudyToolsActivity.java',
    'app/src/main/java/com/studymate/local/ai/LocalLlmEngine.kt',
]
for item in required:
    assert (ROOT / item).is_file(), f'Missing required source: {item}'

manifest = ET.parse(ROOT / required[0]).getroot()
android = '{http://schemas.android.com/apk/res/android}'
activities = [node.attrib.get(android + 'name') for node in manifest.findall('./application/activity')]
assert '.MainActivity' in activities, 'Launcher activity missing'
assert '.ui.DocumentActivity' in activities, 'Document activity missing'
assert '.ui.StudyToolsActivity' in activities, 'Study tools activity missing'
assert not manifest.findall('uses-permission'), 'Unexpected app permissions; review privacy surface'

java = (ROOT / required[5]).read_text()
checks = {
    'search results remain reusable': 'searchResults.removeAllViews()' in java and 'body.removeViews(' not in java,
    'exam count validated': 'exam.length()!=10' in java,
    'four exam options validated': 'options.length()!=4' in java,
    'answer index validated': 'answer>=4' in java,
    'unanswered exam selection guarded': 'Select an answer before submitting.' in java,
    'document-grounded library tutor': 'Answer the student\'s question using only these retrieved passages' in java,
}
for name, ok in checks.items():
    assert ok, f'Failed source check: {name}'

db = (ROOT / required[2]).read_text()
for table in ('documents', 'document_pages', 'study_notes', 'chat_messages', 'flashcards', 'exam_sessions', 'topic_progress'):
    assert f'CREATE TABLE' in db and table in db, f'Missing database feature: {table}'
assert 'ON DELETE CASCADE' in db, 'Document child rows should cascade on deletion'
assert 'idx_pages_document_page' in db, 'Page lookup index missing'

imp = (ROOT / required[3]).read_text()
for ext in ('pdf', 'docx', 'pptx', 'odt', 'epub', 'html', 'rtf'):
    assert f'"{ext}"' in imp, f'Missing importer path: {ext}'
assert 'DevanagariTextRecognizerOptions' in imp, 'Devanagari OCR path missing'
assert 'MAX_FILE_BYTES' in imp and 'MAX_TEXT_CHARS' in imp, 'Import resource limits missing'

print('PASS: required source files present')
print('PASS: Android manifest parses and required activities are registered')
print('PASS: no app permissions are declared')
for name in checks:
    print(f'PASS: {name}')
print('PASS: local database tables, cascading relations and page index present')
print('PASS: supported import paths, OCR and import resource limits present')
print('LIMIT: Android compilation, dependency resolution, runtime and physical-device tests require Android SDK/Gradle/device.')
