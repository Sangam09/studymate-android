package com.studymate.local.util;

public final class StudyPrompts {
    private StudyPrompts() {}

    public static String chunkPrompt(String task, String source, int part, int total) {
        String role;
        switch (task) {
            case "exam":
                role = "Extract the examinable facts, definitions, processes, examples, comparisons, and important details from this source section. Do not invent facts. Keep page/slide references when present. Do not create the final exam yet; create a compact but complete source brief.";
                break;
            case "teach":
                role = "Turn this source section into a beginner-friendly teaching outline. Explain the concepts in plain language, define technical words immediately, add a practical example only when it is supported by the source, and include one quick understanding check. Keep page/slide references.";
                break;
            default:
                role = "Create clear, well-organized study notes from this source section. Capture key ideas, definitions, lists, steps, examples, and important details. Use simple English and keep page/slide references. Do not add unsupported information.";
                break;
        }
        return "You are StudyMate, a careful exam-study tutor.\n" +
                "Work on part " + part + " of " + total + ". This is not the whole document.\n" +
                role + "\n\nSOURCE MATERIAL:\n" + source;
    }

    public static String finalPrompt(String task, String summaries, String documentTitle, int from, int to) {
        String scope = "Document: " + documentTitle + ". Source range: " + from + " to " + to + ".";
        if ("exam".equals(task)) {
            return "You are StudyMate, an exam-preparation tutor. Use only the source briefs below. " +
                    "Build a useful exam pack with: (1) a short topic overview, (2) key definitions, " +
                    "(3) 15 mixed-difficulty multiple-choice questions with four options each, " +
                    "(4) 5 short-answer questions, (5) 3 application/scenario questions, and " +
                    "(6) an answer key at the very end with brief explanations. Do not make up facts. " +
                    "Avoid repeating the same fact. Make the questions test understanding, not just wording.\n" + scope +
                    "\n\nSOURCE BRIEFS:\n" + summaries;
        }
        if ("teach".equals(task)) {
            return "You are a patient but accurate tutor. Teach the selected source range step by step in simple English. " +
                    "Start with the big picture, then teach each concept in a sensible order. Define every technical term. " +
                    "Use realistic examples, but clearly distinguish examples from facts in the material. " +
                    "After each major concept include a short checkpoint question and its answer after a divider. " +
                    "Finish with a small recap and 5 questions for the student to answer. Do not add unsupported syllabus content.\n" +
                    scope + "\n\nSECTION TEACHING NOTES:\n" + summaries;
        }
        return "You are StudyMate, a careful study-notes editor. Consolidate the source briefs into one clean set of notes. " +
                "Use headings, short explanations, bullet points only where useful, key terms, and a final quick-revision section. " +
                "Remove duplication but do not remove examinable facts. Keep page/slide references. " +
                "Do not invent or assume missing information. Write in clear, student-friendly English.\n" + scope +
                "\n\nSOURCE BRIEFS:\n" + summaries;
    }

    public static String questionPrompt(String documentTitle, String context, String history, String question) {
        return "You are StudyMate, an offline tutor helping a student study from their own material.\n" +
                "Document: " + documentTitle + ".\n" +
                "Prior conversation (oldest first):\n" + (history.isEmpty() ? "(No earlier messages.)" : history) + "\n" +
                "Relevant source material:\n" + context + "\n\n" +
                "Student's question: " + question + "\n\n" +
                "Answer rules: explain clearly in simple English; answer the actual question; cite source page/slide numbers when possible; " +
                "say plainly when the material does not contain enough information; distinguish textbook facts from general explanation; " +
                "do not pretend to have read pages that were not included in the context.";
    }
}
