# StudyMate — Android local-AI study app

A Java-first Android Studio project for turning class materials into searchable study content, notes, lessons, exam packs and document-grounded Q&A.

**This is a source-code MVP, not a finished Play Store release.** It contains the Android app, a local SQLite backend, document extraction, OCR fallback and an on-device LLM adapter. It has not been built or run on a physical Android device in this environment because no Android SDK or Gradle installation was available here. Open and build it in a current Android Studio installation before treating it as release-ready.

## Included in this build

- Import PDF, DOCX, PPTX, ODT, TXT, Markdown, CSV, HTML, RTF and EPUB files using Android's document picker.
- Copy source files into the app's private storage; no cloud account or server is required.
- Extract PDF text per page, Word text, PowerPoint text per slide, OpenDocument text, and text/HTML-based formats.
- OCR PDF pages that have little/no embedded text using on-device ML Kit Latin text recognition when Google Play services is available.
- Store document metadata, extracted page/slide/section text, generated notes and recent chat messages in local SQLite.
- Choose a `.litertlm` model stored on the phone and load it through Google's LiteRT-LM runtime.
- Generate consolidated notes and exam-preparation packs by analysing the selected source range in bounded chunks.
- Teach a page/slide range in beginner-friendly steps.
- Ask questions grounded in a selected document range, with recent local conversation history included in the prompt.
- CPU inference backend in this first version for broader device compatibility.

## Technology

- Android application: Java 17, Android SDK 37, minimum Android API 24.
- One Kotlin adapter: `LocalLlmEngine.kt`. Google's supported LiteRT-LM Android API is currently Kotlin-based, so the Kotlin file is the narrow bridge. UI, import, local database, context building and study prompts are Java.
- Local database: SQLite through `SQLiteOpenHelper`.
- PDF extraction: PdfBox-Android.
- Scanned PDF OCR: ML Kit Text Recognition (Latin script).
- On-device LLM: LiteRT-LM Android `0.19.1`; model files are selected by the user and are not bundled in the APK.

## Build requirements

- Android Studio Panda 3 or newer, with support for Android Gradle Plugin 9.5.x.
- JDK 17.
- Android SDK Platform 37 and Build Tools 36.0.0 or newer as required by the installed AGP.
- Gradle 9.6.0.
- An Android phone with sufficient free storage and RAM for the model you choose. LLM inference is far more practical on a recent phone; older/low-memory devices may be slow or unable to load larger models.

### Build

1. Install Android Studio Panda 3 or newer, JDK 17, Android SDK Platform 37 and Gradle 9.6.0.
2. This source bundle includes the wrapper properties but not the binary `gradle-wrapper.jar` or the `gradlew` launch scripts. Generate them once from an installed Gradle 9.6.0 distribution by running `gradle wrapper --gradle-version 9.6.0` in the project folder, or configure Android Studio to use your local Gradle 9.6.0 installation.
3. Open the `StudyMateAndroid` folder in Android Studio and allow Gradle to sync and download dependencies.
4. Build with **Build → Make Project** or run the `app` configuration on a physical device.

## Set up the on-device model

1. Open the **Local AI** tab in StudyMate.
2. Follow the model collection link to `https://huggingface.co/litert-community`.
3. Download a compatible `.litertlm` instruction/chat model. Start with a small model (around 1B parameters) before trying larger models. Model format matters: this app expects LiteRT-LM `.litertlm`, not GGUF, `.task`, or arbitrary `.tflite` files.
4. Return to StudyMate and choose the `.litertlm` file. The app copies it into its private model folder and loads it on a background executor.
5. After the model is loaded, open any document and use Teach, Make Notes, Exam Prep or Ask StudyMate.

Do not put a multi-gigabyte model in `assets/`; the model is loaded from device storage. Use a model whose licence permits your intended use and whose memory requirements fit the phone.

## How long documents are handled

The app does not send an entire book as one oversized prompt. For notes, teaching and exam preparation, it divides the selected page/slide range into smaller source chunks, asks the local model to extract a brief from each chunk, and then combines those briefs into the final output. This reduces truncation and helps smaller models work with larger material. The final synthesis still has a finite context budget; very long books may need to be studied chapter by chapter.

Question answering builds a bounded context from the selected range. For precise questions about a large PDF, select the smallest useful page range rather than the entire file.

## Important limitations — do not mistake these for finished features

- “Unlimited local AI” is not technically realistic. The app avoids a per-request API fee and can work without a cloud model after setup, but RAM, storage, context length, processing speed, heat, battery and model licence still constrain usage.
- A `.litertlm` model must be compatible with the installed LiteRT-LM version and the device's supported backend. The app defaults to CPU; some models may still exceed a phone's available memory.
- The PDF OCR fallback tries both Latin and Devanagari recognizers on pages where embedded text extraction finds almost nothing. OCR depends on Google Play services and may need to obtain recognition models before first use. Handwriting, low-quality scans and complex tables are not guaranteed.
- Password-protected PDFs, malformed Office files, image-heavy layouts, diagrams, tables and handwriting may not extract accurately. This version extracts text; it does not yet create searchable embeddings or visually interpret every figure.
- DOCX and ODT are stored as a logical section because printed pagination can change with fonts and device layout. PPTX is divided by slide. EPUB chapters are extracted from their HTML/XHTML entries; some books may have unusual internal chapter ordering.
- Old binary Office formats (`.doc`, `.ppt`), Excel workbooks (`.xls`, `.xlsx`), scanned images as standalone inputs, audio/video, handwriting and cloud sync are not included in this first build.
- Quiz generation currently returns questions and an answer key as text; an interactive timed quiz/answer-marking screen is a next-stage feature.
- Model selection is manual. This bundle does not auto-download a model or include one in the APK.

## Privacy and permissions

- Imported files, extracted text, generated notes and saved chat are written to app-private storage and local SQLite.
- No document upload endpoint, analytics SDK or cloud AI API is implemented.
- The app declares no Android permissions. The local LLM itself does not require a network request after the model is installed. Selecting the model collection opens an external browser only when the user taps the link; Google Play services manages any OCR model download independently.
- Uninstalling the app removes its private database, imported copies and selected model.

## Project map

```text
app/src/main/java/com/studymate/local/
  MainActivity.java                 Home, Library and Local AI setup UI
  StudyApplication.java             Application-scoped local AI runtime
  ai/LocalLlmEngine.kt              Kotlin bridge to LiteRT-LM
  data/StudyDatabase.java           SQLite documents/pages/notes/chat
  importer/StudyImporter.java       PDF, Office, EPUB, text and HTML import
  ui/DocumentActivity.java          Page range, lesson, notes, exam and Q&A screen
  util/ContextBuilder.java          Bounded context/chunk creation
  util/StudyPrompts.java            Tutor, note, exam and Q&A prompt templates
```

## Next engineering milestones

1. Add automated JVM/instrumentation tests for document extraction, page-range selection, chunk ordering and database migrations.
2. Add Devanagari OCR, image import, tables/figures extraction and workbook support.
3. Add interactive flashcards, MCQ answer marking, spaced repetition, bookmarks and weak-topic tracking.
4. Add hybrid retrieval (local embeddings + page citations) so Q&A can find relevant passages across very large libraries instead of relying only on a manually selected range.
5. Add streaming token output, cancellation, model compatibility checks, memory estimates and optional GPU acceleration.
6. Add export/share of notes and backup/restore with explicit user control.
7. Run performance, battery, thermal, accessibility, privacy and security tests across low-, mid- and high-memory Android devices before release.

## Study tools added in version 0.2 source update

- **Interactive exams:** the local model generates a structured 10-question JSON exam from the selected document. Each answer is submitted individually, the correct answer is shown, and the final score is saved locally.
- **Flashcards:** generate cards from a document and review due cards. The scheduler uses a simple SM-2-inspired interval/ease update based on Again / Hard / Know it ratings. Re-generating a deck skips duplicate front-side prompts within the same document.
- **Library search and tutor:** search extracted page/section text across the local library. The tutor retrieves matching passages and asks the local model to answer with `[Document, page N]` citations. Search is keyword-based (SQLite `LIKE`), not semantic/vector search; synonyms and paraphrases can be missed.
- **Progress and weak topics:** exam attempts, correctness by topic and flashcard due counts are stored in SQLite. Topics are ordered by observed accuracy; small sample sizes should not be treated as reliable mastery estimates.
- **Nepali/Devanagari OCR:** scanned PDF pages are now tried with both Latin and Devanagari ML Kit recognizers. The Devanagari model is an optional Google Play services module and may need to download before first use. OCR accuracy depends on scan quality; handwriting and complex tables are not guaranteed.

The new **Study tools** screen is available from Home. When opened from an individual document, it uses that document. When opened from Home, it uses the most recently imported document for generation/review; library search still searches every imported document.

## Important implementation boundaries

The exam generator expects valid JSON from the local model. Smaller models sometimes return malformed JSON; in that case the app reports a parsing failure and the user can retry with a smaller document. Whole-library Q&A is retrieval-augmented keyword search over extracted text, not an embeddings-based semantic index. A follow-up milestone should add robust JSON repair/validation, a user-visible document chooser, multi-turn library chat persistence, semantic retrieval, per-question explanations, exam resume, and device instrumentation tests.

### Devanagari OCR dependency

The app uses `com.google.android.gms:play-services-mlkit-text-recognition-devanagari:16.0.2` alongside the Latin recognizer. Google documents the Devanagari options class and model dependency metadata in its Android Text Recognition guide: https://developers.google.com/ml-kit/vision/text-recognition/v2/android


## Source-level QA performed for the current update

Run `python3 tools/qa_check.py` from the project root. It checks manifest XML, required app components, declared permissions, the exam validation guards, reusable search UI, database tables/relations, supported import paths, OCR wiring and import size limits. The check passes in the supplied environment.

**This is not an Android build test.** The current build environment has no Android SDK, no installed Gradle distribution, no Android platform `android.jar`, and no network access to resolve Gradle plugins/dependencies. Therefore no APK has been compiled, installed or tested on a physical Android device here. A real release still requires Android Studio/Gradle build verification and device testing.
