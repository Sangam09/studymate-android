package com.studymate.local.ai

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import java.util.concurrent.Executors

/**
 * A small Kotlin adapter around Google's current LiteRT-LM Kotlin API.
 * The rest of the application (UI, import, storage, prompts and study logic) is Java.
 * A single executor owns the native Engine and Conversation; never call inference on the UI thread.
 */
class LocalLlmEngine(context: Context) {
    interface Callback {
        fun onSuccess(text: String)
        fun onError(message: String)
    }

    private val appContext = context.applicationContext
    private val owner = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "StudyMate-LiteRT").apply { priority = Thread.NORM_PRIORITY - 1 }
    }

    @Volatile
    private var ready = false
    private var engine: Engine? = null
    private var conversation: Conversation? = null

    fun isLoaded(): Boolean = ready

    fun loadModel(modelPath: String, callback: Callback) {
        ready = false
        owner.execute {
            try {
                closeCurrentSession()
                val candidate = Engine(
                    EngineConfig(
                        modelPath = modelPath,
                        backend = Backend.CPU(),
                        cacheDir = appContext.cacheDir.absolutePath
                    )
                )
                // Model loading can take several seconds. This runs on the dedicated worker.
                candidate.initialize()
                engine = candidate
                conversation = createConversation(candidate)
                ready = true
                callback.onSuccess("Local model loaded. AI is ready to use offline.")
            } catch (error: Throwable) {
                ready = false
                callback.onError(error.message ?: "The local model could not be loaded.")
            }
        }
    }

    fun generate(prompt: String, callback: Callback) {
        owner.execute {
            try {
                val activeEngine = engine ?: throw IllegalStateException("Load a .litertlm model first.")
                // Start a clean turn. The Java layer supplies a short saved-chat history where useful.
                // This prevents unbounded hidden conversation history from filling the model context.
                val previousConversation = conversation
                conversation = null
                previousConversation?.close()
                conversation = createConversation(activeEngine)
                val answer = conversation!!.sendMessage(prompt).toString()
                callback.onSuccess(answer)
            } catch (error: Throwable) {
                callback.onError(error.message ?: "Local inference failed.")
            }
        }
    }

    private fun createConversation(activeEngine: Engine): Conversation {
        val config = ConversationConfig(
            systemInstruction = Contents.of(
                "You are StudyMate, a factual and patient study tutor. Use the provided material carefully. " +
                    "Do not invent textbook facts, and explain technical words in student-friendly language."
            ),
            samplerConfig = SamplerConfig(
                topK = 40,
                topP = 0.90,
                temperature = 0.65
            )
        )
        return activeEngine.createConversation(config)
    }

    private fun closeCurrentSession() {
        ready = false
        val oldConversation = conversation
        conversation = null
        try {
            oldConversation?.close()
        } catch (_: Throwable) {
            // The native session may already have been released after an earlier failure.
        }
        val oldEngine = engine
        engine = null
        try {
            oldEngine?.close()
        } catch (_: Throwable) {
            // Do not let cleanup prevent a new model from being loaded.
        }
    }

    fun shutdown() {
        owner.execute { closeCurrentSession() }
        owner.shutdown()
    }
}
