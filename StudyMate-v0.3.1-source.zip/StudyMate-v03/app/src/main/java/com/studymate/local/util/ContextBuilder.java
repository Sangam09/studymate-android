package com.studymate.local.util;

import com.studymate.local.data.StudyDatabase;

import java.util.ArrayList;
import java.util.List;

public final class ContextBuilder {
    private ContextBuilder() {}

    /**
     * Splits all selected pages into bounded context blocks. Long individual pages are split too,
     * so a large PDF is processed in multiple local inference calls instead of silently dropping
     * everything after the first few pages.
     */
    public static List<String> makeChunks(List<StudyDatabase.StudyPage> pages, int maxCharacters) {
        List<String> chunks = new ArrayList<>();
        if (pages == null || pages.isEmpty()) return chunks;
        int safeLimit = Math.max(1500, maxCharacters);
        StringBuilder current = new StringBuilder();

        for (StudyDatabase.StudyPage page : pages) {
            String text = page.content == null ? "" : page.content;
            if (text.trim().isEmpty()) continue;
            int offset = 0;
            while (offset < text.length()) {
                String marker = "\n[Source page/slide " + page.pageNumber + "]\n";
                int capacity = safeLimit - current.length() - marker.length();
                if (capacity < 300 && current.length() > 0) {
                    chunks.add(current.toString());
                    current.setLength(0);
                    capacity = safeLimit - marker.length();
                }
                int take = Math.min(text.length() - offset, Math.max(1, capacity));
                if (take < text.length() - offset && take > 250) {
                    int splitAt = text.lastIndexOf(' ', offset + take);
                    if (splitAt > offset + (take / 2)) take = splitAt - offset;
                }
                current.append(marker).append(text, offset, offset + take).append('\n');
                offset += take;
                if (offset < text.length()) {
                    chunks.add(current.toString());
                    current.setLength(0);
                }
            }
        }
        if (current.length() > 0) chunks.add(current.toString());
        return chunks;
    }

    public static String joinSummaries(List<String> summaries, int maxCharacters) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < summaries.size(); i++) {
            String section = "\n[Section " + (i + 1) + "]\n" + summaries.get(i).trim() + "\n";
            if (out.length() + section.length() > maxCharacters) {
                int remaining = maxCharacters - out.length();
                if (remaining > 100) out.append(section, 0, remaining);
                break;
            }
            out.append(section);
        }
        return out.toString();
    }

    public static String recentChatAsContext(List<StudyDatabase.ChatMessage> messages) {
        StringBuilder out = new StringBuilder();
        for (StudyDatabase.ChatMessage message : messages) {
            out.append(message.role.equals("user") ? "Student: " : "Tutor: ")
                    .append(message.content).append("\n");
        }
        String value = out.toString();
        if (value.length() > 1800) value = value.substring(value.length() - 1800);
        return value;
    }
}
